﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MSCommon
{
	public static class CommonConstants
	{
		public const int MasterServerPort = 14343;
		public const int GameServerPort = 14242;
	}
}
